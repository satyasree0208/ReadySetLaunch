/**
 * router.js — Client-Side Page Router
 * ReadySetLaunch
 */

'use strict';

/**
 * Show a page by its element ID and hide all others.
 * @param {string} id - The ID of the page element to show.
 */
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

  const target = document.getElementById(id);
  if (!target) {
    console.warn(`showPage: no element found with id "${id}"`);
    return;
  }

  target.classList.add('active');

  // Hide nav on the home page
  const hideNavOn = ['home'];
  const nav = document.getElementById('mainNav');
  if (nav) {
    nav.style.display = hideNavOn.includes(id) ? 'none' : 'flex';
  }

  window.scrollTo(0, 0);
}

// ── Boot ──
document.addEventListener('DOMContentLoaded', () => {
  showPage('home');
});
