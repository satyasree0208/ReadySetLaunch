/**
 * readiness.js — Live Readiness Meter (Product Input Page)
 * ReadySetLaunch
 */

'use strict';

const READINESS_FIELDS  = ['projName', 'targetUsers', 'problemStmt', 'keyFeatures'];
const BASE_READINESS    = 10;   // minimum % shown before any input
const PER_FIELD_GAIN    = 22;   // readiness points per filled field
const PER_FIELD_ACC     = 24;   // accuracy points per filled field
const GAUGE_CIRCUMFERENCE = 345.4; // 2π × r where r = 55

/**
 * Recalculate and render the readiness gauge + accuracy bar
 * whenever a product-input field changes.
 */
function updateReadiness() {
  let filled = 0;

  READINESS_FIELDS.forEach(fieldId => {
    const el = document.getElementById(fieldId);
    if (el && el.value.trim().length > 3) filled++;
  });

  const readiness = Math.min(BASE_READINESS + filled * PER_FIELD_GAIN, 100);
  const accuracy  = Math.min(filled * PER_FIELD_ACC, 98);

  // Text values
  const gaugeVal   = document.getElementById('gaugeVal');
  const accuracyVal = document.getElementById('accuracyVal');
  const accuracyFill = document.getElementById('accuracyFill');
  const gaugeFill  = document.getElementById('gaugeFill');

  if (gaugeVal)    gaugeVal.textContent    = readiness + '%';
  if (accuracyVal) accuracyVal.textContent = accuracy  + '%';
  if (accuracyFill) accuracyFill.style.width = accuracy + '%';

  // SVG stroke-dashoffset: 0 = full circle, CIRCUMFERENCE = empty
  if (gaugeFill) {
    const offset = GAUGE_CIRCUMFERENCE - (readiness / 100) * GAUGE_CIRCUMFERENCE;
    gaugeFill.setAttribute('stroke-dashoffset', offset.toFixed(1));
  }
}
