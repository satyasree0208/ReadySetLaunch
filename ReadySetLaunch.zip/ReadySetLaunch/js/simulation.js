/**
 * simulation.js — Launch Simulation Controls
 * ReadySetLaunch
 */

'use strict';

/**
 * Run the launch simulation — hide the start card and show results.
 */
function runSimulation() {
  const startCard = document.getElementById('simStart');
  const resultEl  = document.getElementById('simResult');

  if (startCard) startCard.style.display = 'none';
  if (resultEl)  resultEl.classList.add('visible');
}

/**
 * Reset the simulation back to the start state.
 */
function resetSimulation() {
  const startCard = document.getElementById('simStart');
  const resultEl  = document.getElementById('simResult');

  if (resultEl)  resultEl.classList.remove('visible');
  if (startCard) startCard.style.display = 'block';
}

/**
 * Select a platform card (toggle selected state).
 * @param {HTMLElement} el - The clicked platform card.
 */
function selectPlatform(el) {
  document.querySelectorAll('.platform-card').forEach(c => c.classList.remove('selected'));
  el.classList.add('selected');
}
