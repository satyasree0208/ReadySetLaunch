/**
 * checklist.js — Launch Readiness Checklist Logic
 * ReadySetLaunch
 */

'use strict';

const SECTIONS = ['market', 'tech', 'ops', 'ux'];

/**
 * Toggle the done state of a checklist item and refresh progress.
 * @param {HTMLElement} el      - The clicked check-item element.
 * @param {string}      section - The section key (e.g. 'market').
 */
function toggleCheck(el, section) {
  el.classList.toggle('done');
  updateProgress();
}

/**
 * Recalculate and render overall + per-section progress.
 */
function updateProgress() {
  const allItems  = document.querySelectorAll('#checklist .check-item');
  const doneItems = document.querySelectorAll('#checklist .check-item.done');
  const total     = allItems.length;
  const completed = doneItems.length;
  const pct       = total > 0 ? Math.round((completed / total) * 100) : 0;

  // Overall bar
  const progressText = document.getElementById('progressText');
  const progressBar  = document.getElementById('progressBar');
  const progressPct  = document.getElementById('progressPct');

  if (progressText) progressText.textContent = `${completed} of ${total} tasks completed`;
  if (progressBar)  progressBar.style.width  = pct + '%';
  if (progressPct)  progressPct.textContent  = pct + '%';

  // Per-section percentages
  SECTIONS.forEach(section => {
    const pctEl = document.getElementById('pct-' + section);
    if (!pctEl) return;

    const sectionItems = [...document.querySelectorAll(
      `#checklist .check-item[onclick*="${section}"]`
    )];

    if (sectionItems.length === 0) return;

    const sectionDone = sectionItems.filter(i => i.classList.contains('done')).length;
    const sectionPct  = Math.round((sectionDone / sectionItems.length) * 100);
    pctEl.textContent = sectionPct + '%';
  });
}
